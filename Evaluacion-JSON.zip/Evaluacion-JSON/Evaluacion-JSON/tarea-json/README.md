﻿# Implementación API rest
Modifiqué la base de datos porque no estaba mostrando los 5 registros que estaban en el archivo db init. <br>
También deje que los id se tomaran como enteros ya que me resultaba un error cuando la task3 agregaba un nuevo usuario. <br>
El archivo test me estaba leyendo los id como string entonces también fue modificado. <br>
