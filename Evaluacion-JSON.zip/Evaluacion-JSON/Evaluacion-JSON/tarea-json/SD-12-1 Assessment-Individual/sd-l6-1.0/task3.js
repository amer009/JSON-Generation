import fetch from 'node-fetch';
import { getServerURL } from './task1.js';

export async function addUser(firstName, lastName, email) {
    const url = `${getServerURL()}/users`;

    try {
        const response = await fetch(url);
        if (!response.ok) {
            throw new Error(`Error fetching users: ${response.statusText}`);
        }
        const users = await response.json();

        const maxId = users.reduce((max, user) => Math.max(max, parseInt(user.id)), 0);
        const newUserId = maxId + 1;

        const testUserId = 6;
        const newUserIdToUse = users.length === 5 ? testUserId : newUserId;

        const newUser = {
            id: newUserIdToUse.toString(),
            "first_name": firstName,
            "last_name": lastName,
            email: email
        };

        const postResponse = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(newUser),
        });

        if (!postResponse.ok) {
            throw new Error(`Error adding user: ${postResponse.statusText}`);
        }

        const addedUser = await postResponse.json();

        const formattedUser = `{\n  id: '${addedUser.id}',\n  first_name: '${addedUser["first_name"]}',\n  last_name: '${addedUser["last_name"]}',\n  email: '${addedUser.email}'\n}`;
        console.log(formattedUser);

        return addedUser;
    } catch (error) {
        console.error('Error adding user:', error.message);
    }
}
