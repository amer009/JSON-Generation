// task1.js
export const getServerURL = () => {
  return 'http://localhost:3000';
};
